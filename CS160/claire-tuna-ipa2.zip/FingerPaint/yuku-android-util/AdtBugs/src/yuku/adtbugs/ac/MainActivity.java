package yuku.adtbugs.ac;

import android.app.Activity;
import android.os.Bundle;

import yuku.adtbugs.R;

public class MainActivity extends Activity {
	@Override public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}
}