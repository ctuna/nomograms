package yuku.atree;

public enum TreeNodeIconType {
	none, // -
	up, // '-
	both, // |-
}
