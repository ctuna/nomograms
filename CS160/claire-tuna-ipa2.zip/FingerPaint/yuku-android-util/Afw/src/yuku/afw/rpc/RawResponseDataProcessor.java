package yuku.afw.rpc;


public interface RawResponseDataProcessor {
	void processRawResponse(byte[] raw);
}
