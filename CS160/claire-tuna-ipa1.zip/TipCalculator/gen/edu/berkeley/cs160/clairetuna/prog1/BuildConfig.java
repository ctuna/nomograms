/** Automatically generated file. DO NOT MODIFY */
package edu.berkeley.cs160.clairetuna.prog1;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}